public class MEC {
    public Universidade[] universidade;
    public Publica pub;
    public Particular part;

    public void ImprimeParticular(Universidade universidade) {
        part= (Particular) universidade;
            System.out.println("Nome da Universidade: " + this.part.getNome());
            System.out.println("Quantidade de Alunos: " + this.part.getQuantidadeDeAlunos());
            System.out.println("Quantidade de Professores: " + this.part.getQuantidadeDeProfessores());
            System.out.println("Valor da Universidade: " + this.part.getValorDeMensalidade());
    }

    public void universidadesDoSul(Universidade universidade) {
        if(universidade instanceof Publica) {
            pub = (Publica) universidade;
            if (((Publica) universidade).getEstado().equalsIgnoreCase("RS") || ((Publica) universidade).getEstado().equalsIgnoreCase("SC") || ((Publica) universidade).getEstado().equalsIgnoreCase("PR"))
                System.out.println("Nome da Universidade: " + pub.getNome());
            System.out.println("Quantidade de Alunos: " + pub.getQuantidadeDeAlunos());
            System.out.println("Quantidade de Professores: " + pub.getQuantidadeDeProfessores());
            System.out.println("Estado da Universidade: " + pub.getEstado());
            System.out.println("Cidade da Universidade: " + pub.getCidade());
        }
    }
}