public class Principal {
    public static void main(String[] args) {
        Universidade[] universidade = new Universidade[Teclado.leInt("Digite o número de Universidades que deseja: ")];
        Particular parti;
        System.out.println("Agora vamos preencher os " + universidade.length + " espaços do arrey!");
        double preco1 = 0;
        for (int i = 0; i < universidade.length; i++) {
            int a = Teclado.leInt("Digite [1] para Universidade Particular\nDigite [2] para Universidade Pública");
            if (a == 1) {
                String nombre = Teclado.leString("Digite o nome da  Universidade: ");
                int quantA = Teclado.leInt("Digite a quantidade de Alunos: ");
                int quantP = Teclado.leInt("Digite a quantidade de Professores: ");
                preco1 = Teclado.leDouble("Digite o valor da mensalidade da Universidade: ");
                universidade[i] = new Particular(nombre, quantA, quantP, preco1);
            } else if (a == 2) {
                String nombre1 = Teclado.leString("Digite o nome da  Universidade: ");
                String estad = Teclado.leString("Digite o estado da  Universidade: ");
                String cidad = Teclado.leString("Digite a cidade da  Universidade: ");
                int quantA1 = Teclado.leInt("Digite a quantidade de Alunos: ");
                int quantP1 = Teclado.leInt("Digite a quantidade de Professores: ");
                universidade[i] = new Publica(nombre1, estad, cidad, quantA1, quantP1);
            } else {
                System.out.println("Erro, programa finalizando!");
                break;
            }
        }
        for (int i=0; i<universidade.length; i++){
            if(universidade[i]!=null){
                System.out.println(universidade[i].toString());
            }
        }
        Particular altoValor = null;
        for (int i = 0; i < universidade.length; i++) {
            if (universidade[i] instanceof Particular)
                if (altoValor == null) {
                    altoValor = (Particular) universidade[i];
                } else {
                    if (((Particular) universidade[i]).getValorDeMensalidade() > altoValor.getValorDeMensalidade()) {
                        altoValor = (Particular) universidade[i];
                    }
                }
        }
        if (altoValor != null) {
            System.out.println("Nome da Universidade: " + altoValor.getNome());
            System.out.println("Quantidade de Alunos: " + altoValor.getQuantidadeDeAlunos());
            System.out.println("Quantidade de Professores: " + altoValor.getQuantidadeDeProfessores());
            System.out.println("Valor da Universidade: " + altoValor.getValorDeMensalidade());
        } else {
            System.out.println("Não existem faculdades particulares!!!");
        }
    }
}

