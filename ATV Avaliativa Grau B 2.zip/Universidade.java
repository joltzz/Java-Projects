public class Universidade {
    private String nome;
    private int quantidadeDeAlunos;
    private int quantidadeDeProfessores;

    public Universidade(String nome, int quantidadeDeAlunos, int quantidadeDeProfessores) {
        this.nome=nome;
        this.quantidadeDeAlunos=quantidadeDeAlunos;
        this.quantidadeDeProfessores=quantidadeDeProfessores;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidadeDeAlunos() {
        return quantidadeDeAlunos;
    }

    public void setQuantidadeDeAlunos(int quantidadeDeAlunos) {
        this.quantidadeDeAlunos = quantidadeDeAlunos;
    }

    public int getQuantidadeDeProfessores() {
        return quantidadeDeProfessores;
    }

    public void setQuantidadeDeProfessores(int quantidadeDeProfessores) {
        this.quantidadeDeProfessores = quantidadeDeProfessores;
    }
    public String toString() {
        return "Universidade{" +
                "nome='" + nome + '\'' +
                ", quantidadeDeAlunos=" + quantidadeDeAlunos +
                ", quantidadeDeProfessores=" + quantidadeDeProfessores +
                '}';
    }
}