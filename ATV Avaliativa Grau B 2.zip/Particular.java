public class Particular extends Universidade{
    private double valorDeMensalidade;

    public Particular(String nome, int quantidadeDeAlunos, int quantidadeDeProfessores,double valorDeMensalidade) {
        super(nome, quantidadeDeAlunos, quantidadeDeProfessores);
    }

    public double getValorDeMensalidade() {
        return valorDeMensalidade;
    }

    public void setValorDeMensalidade(double valorDeMensalidade) {
        this.valorDeMensalidade = valorDeMensalidade;
    }
    public String toString() {
        return "Particular{" +
                "valorDeMensalidade=" + valorDeMensalidade +
                '}';
    }
}